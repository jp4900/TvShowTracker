import type { ReactNode } from "react";
import Navbar from "./Navbar";

interface LayoutProps {
  children: ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  return (
    <div className="min-h-screen bg-dark-primary">
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

      <footer className="bg-dark-secondary border-t border-dark-300 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-dark-500">
            <p className="text-sm">© 2025 TV Show Tracker.</p>
            <p className="text-xs mt-2 text-dark-400">
              GDPR Compliant • Your data, your control
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
